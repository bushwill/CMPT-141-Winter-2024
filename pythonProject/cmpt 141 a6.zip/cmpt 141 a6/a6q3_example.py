# If you want me to go over codelab questions on the projector let me know
# My email is william.bushell@usask.ca if you have questions outside of lab/help desk hours, or if you want this code emailed to you

# This is the formatting for question 3 of assignment 6
database = {"bulbasaur":{"Name":"bulbasaur", "Type":"grass", "Locations":["South America"]},"ivysaur":{"Name":"ivysaur", "Type":"grass", "Locations":["Asia", "Antarctica"]}}

# For the testing questions...
# Let's test a function using black box
# This means we cannot see the code we are testing
# We will be testing a function called fibonacci that takes a number n and returns the nth fibonacci number

# Fibonacci is not an equation but a pre defined sequence of numbers
# So when I call the fibonacci function with n, it is finding the nth number in this sequence
# Sequence looks like: 1, 1, 2, 3, 5, 8, 13, 21, 34, ...
# So if n == 6, 6th fibonacci number is 8, function should return 8

# So n must be a positive integer, as we cannot find the 0th, -5th, or 0.37th number of a sequence

# Now that we understand this function, we now find some test cases

# What are all of the possible "branches" we can find in this function by passing through varying values of n?

# 1st branch: if n == 1     (n == 1)
# 2nd branch: elif n == 2   (n == 2)
# 3rd branch: else:         (n > 2) or ((n != 1 and n != 2) and n > 0)

# The IDE (PyCharm) will tell you that there is an error and fibonacci function is not found, this is okay.
# As long as this woukd work if you copied and pasted it into the file with fibonacci function.
# Let's now build the tests:

from fib_file import fibonacci

fib_input = 1                       # 1st branch
fib_result = fibonacci(fib_input)
expected_result = 1
assert fib_result == expected_result, f"Expected {expected_result} but instead got {fib_result}"

fib_input = 2                       # 2nd branch
fib_result = fibonacci(fib_input)
expected_result = 1
assert fib_result == expected_result, f"Expected {expected_result} but instead got {fib_result}"

fib_input = 7                       # 3rd branch
fib_result = fibonacci(fib_input)
expected_result = 13
assert fib_result == expected_result, f"Expected {expected_result} but instead got {fib_result}"

# If no errors, tests passed
print("Tests completed successfully!")
