# Lab 7 Checkpoint

# Write a program that PRINTs the value of the REMAINDER of N divided by 5
# for every number N from 0 through 15 (inclusive).

for i in range(0, 16):
    print(i, i%5)