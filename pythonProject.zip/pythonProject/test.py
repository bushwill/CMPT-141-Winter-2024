file = open("test1.txt", "r")
pokedict = {}

for line in file:
    pokemon = line.strip().split(",")
    pokedict[pokemon[0]] = {"Name":pokemon[0], "Type":pokemon[1], "Locations":pokemon[2:]}
    
